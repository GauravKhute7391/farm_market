<?php
session_start();
include('../config.php');

$message = "";

// Fetch schedules from farm_schedule table
$schedules = mysqli_query($conn, "SELECT * FROM farm_schedule ORDER BY schedule_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Market Schedule</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'Montserrat', sans-serif;
  margin:0; padding:0;
  min-height:100vh;
  background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
              url('../assets/farm7.jpg') no-repeat center center/cover;
  color:#fff;
  animation: fadeBody 1s ease forwards;
}
@keyframes fadeBody { from {opacity:0;} to {opacity:1;} }

.container {
  width:90%;
  max-width:1200px;
  margin:40px auto;
  background: rgba(255,255,255,0.2);
  backdrop-filter: blur(15px);
  border-radius: 20px;
  padding: 25px 30px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.4);
  animation: fadeIn 1s ease forwards;
}
@keyframes fadeIn { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }

h2 {
  text-align:center;
  margin-bottom:25px;
  color:#FFD700;
  text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
}

table {
  width:100%;
  border-collapse: collapse;
  background: rgba(255,255,255,0.1);
  border-radius: 12px;
  overflow: hidden;
}
th, td {
  padding:12px;
  border-bottom: 1px solid rgba(255,255,255,0.3);
  text-align:center;
  color:#fff;
}
th {
  background:#FFD700;
  color:#333;
  text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
}
tr:hover {
  background: rgba(255,255,255,0.2);
  transform: scale(1.01);
  transition:0.3s;
}

.back {
  text-align:center;
  margin-top:25px;
}
.back a {
  color:#333;
  background:#FFD700;
  padding:10px 20px;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  transition:0.3s;
}
.back a:hover {
  background:#e6c200;
  transform: translateY(-2px) scale(1.03);
  box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

/* Responsive */
@media(max-width:600px){
  th, td { font-size:0.85rem; padding:8px; }
}
</style>
</head>
<body>

<div class="container">
  <h2>📋 Market Schedule</h2>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Activity</th>
        <th>Farm Seed</th>
        <th>Date</th>
        <th>Assigned Employee</th>
        <th>Remarks</th>
      </tr>
    </thead>
    <tbody>
      <?php if (mysqli_num_rows($schedules) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($schedules)): ?>
          <tr>
            <td><?= $row['schedule_id']; ?></td>
            <td><?= htmlspecialchars($row['activity_name']); ?></td>
            <td><?= htmlspecialchars($row['farm_seed_type']); ?></td>
            <td><?= $row['schedule_date']; ?></td>
            <td><?= htmlspecialchars($row['assigned_employee']); ?></td>
            <td><?= htmlspecialchars($row['remarks']); ?></td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="6">No scheduled activities yet.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <div class="back">
    <a href="dashboard.php">⬅ Back to Dashboard</a>
  </div>
</div>

</body>
</html>

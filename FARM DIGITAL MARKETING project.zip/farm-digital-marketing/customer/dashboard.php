<?php
session_start();
include('../config.php');

// For demo, get logged-in customer id
$customer_id = $_SESSION['user_id'] ?? 1;

// Fetch customer info
$customer_query = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = $customer_id");
$customer = mysqli_fetch_assoc($customer_query);

// Fetch employee requests for this customer
$requests = mysqli_query($conn, "SELECT * FROM employee_requests WHERE customer_id=$customer_id");

// Fetch market schedule
$market_schedule = mysqli_query($conn, "SELECT * FROM farm_schedule ORDER BY schedule_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Montserrat', sans-serif;
    margin:0;
    padding:0;
    min-height: 100vh;
    /* Background image with dark overlay */
    background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('../assets/farm7.jpg') no-repeat center center/cover;
    color: #333;
}

.header {
    background: #FFD700;
    padding: 25px 20px;
    color: #fff;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    position: relative;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
}
.header h1 {
    margin:0;
    font-size:2rem;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.2);
}
.logout-btn {
    position: absolute;
    right: 20px;
    top: 25px;
    background: #ff4d4d;
    color: #fff;
    padding: 8px 15px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: 0.3s;
}
.logout-btn:hover {
    background: #e60000;
}

.container {
    width:90%;
    max-width:1200px;
    margin:30px auto;
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap:20px;
}

.card {
    background: rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
    transition: 0.3s;
    text-align: center;
}
.card:hover {
    transform: translateY(-5px) scale(1.03);
    box-shadow: 0 12px 30px rgba(0,0,0,0.15);
}
.card h3 {
    margin-top:0;
    color: #FFD700;
    font-weight:600;
    font-size:1.3rem;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
}
.card p {
    color: #fff;
    font-size:0.95rem;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
}
.card a {
    text-decoration:none;
    color:#fff;
    background: #FFD700;
    display:inline-block;
    padding:10px 18px;
    margin-top:15px;
    border-radius:8px;
    font-weight:600;
    transition:0.3s;
}
.card a:hover {
    background:#e6c200;
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
}

@media(max-width:500px){
    .container { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<div class="header">
    <h1>Welcome, <?= htmlspecialchars($customer['full_name']); ?></h1>
    <a href="../logout.php" class="logout-btn">Logout</a>
</div>

<div class="container">
    <!-- Add Seeds Card -->
    <div class="card">
        <h3>Add Seeds</h3>
        <p>Update the seeds you have available to sell in the market.</p>
        <a href="add_seed.php">Add Seeds</a>
    </div>

     <div class="card">
        <h3>Employees Available</h3>
        <p>View all employee's available on the market to get visit.</p>
        <a href="view_emp.php">View Employee's</a>
    </div>

    <!-- Seed Price Card -->
    <div class="card">
        <h3>Price of Seeds</h3>
        <p>View prices for the seeds you are selling.</p>
        <a href="seed_prices.php">View Prices</a>
    </div>

    <!-- Market Schedule Card -->
    <div class="card">
        <h3>Market Schedule</h3>
        <p>Total Activities: <?= mysqli_num_rows($market_schedule); ?></p>
        <a href="market_schedule.php">View Schedule</a>
    </div>

    <!-- Contact Us Card -->
    <div class="card">
        <h3>Contact Us</h3>
        <p>Reach out to us for any queries or support.</p>
        <a href="contact.php">Contact Page</a>
    </div>

    <!-- About Us Card -->
    <div class="card">
        <h3>About Us</h3>
        <p>Know more about our farm digital marketing platform.</p>
        <a href="about.php">About Page</a>
    </div>
</div>

</body>
</html>

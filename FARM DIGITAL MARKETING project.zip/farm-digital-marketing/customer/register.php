<?php
session_start();
include('../config.php');

$message = "";

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $farm_available = trim($_POST['farm_available']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $registration_date = date("Y-m-d");

    if ($password !== $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        // Check if email already exists
        $check_query = "SELECT * FROM customers WHERE email='$email' LIMIT 1";
        $check_result = mysqli_query($conn, $check_query);
        if (mysqli_num_rows($check_result) > 0) {
            $message = "Email already registered!";
        } else {
            $insert_query = "INSERT INTO customers (full_name, email, password, phone, farm_available, created_at)
                             VALUES ('$full_name','$email','$password','$phone','$farm_available','$registration_date')";
            if (mysqli_query($conn, $insert_query)) {
                $message = "Registration successful! You can now login.";
            } else {
                $message = "Error: ".mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customer Registration</title>
<style>
  /* Fade-in animation */
  @keyframes fadeIn {
    from { opacity:0; transform: translateY(20px);}
    to { opacity:1; transform: translateY(0);}
  }

  body {
    margin:0;
    padding:0;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    /* Background image with overlay */
    background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('../assets/farm3.webp') no-repeat center center/cover;
    color:#fff;
    animation: fadeIn 1s ease forwards;
  }

  .form-container {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    padding: 40px 35px;
    border-radius: 15px;
    width: 400px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    animation: fadeIn 1.2s ease forwards;
  }

  .form-container h2 {
    text-align:center;
    margin-bottom:25px;
    font-size:2rem;
    text-shadow:2px 2px 6px rgba(0,0,0,0.5);
  }

  .form-container input, .form-container select {
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:10px;
    outline:none;
    font-size:1rem;
  }

  .submit-btn {
    width:100%;
    padding:12px;
    margin-top:15px;
    background:#FF6F61;
    border:none;
    color:#fff;
    font-size:1.1rem;
    font-weight:bold;
    border-radius:10px;
    cursor:pointer;
    transition: transform 0.3s, background 0.3s, box-shadow 0.3s;
  }

  .submit-btn:hover {
    background:#e65c50;
    transform: translateY(-5px) scale(1.05);
    box-shadow:0 10px 25px rgba(0,0,0,0.4);
  }

  .message {
    text-align:center;
    margin-bottom:15px;
    font-weight:bold;
    color:#0f0;
    animation: fadeIn 0.8s ease;
  }

  .back-link {
    text-align:center;
    margin-top:20px;
  }

  .back-link a {
    display:inline-block;
    padding:10px 20px;
    background:#00BFFF;
    color:#fff;
    font-weight:bold;
    text-decoration:none;
    border-radius:10px;
    transition: transform 0.3s, background 0.3s, box-shadow 0.3s;
  }

  .back-link a:hover {
    background:#009acd;
    transform: translateY(-3px) scale(1.05);
    box-shadow:0 8px 20px rgba(0,0,0,0.3);
  }

  @media (max-width: 420px) {
    .form-container { width:90%; padding:30px 20px; }
    .form-container h2 { font-size:1.5rem; }
  }
</style>
</head>
<body>

<div class="form-container">
    <h2>Customer Registration</h2>

    <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="phone" placeholder="Phone">
        <select name="farm_available" required>
            <option value="">-- Select Farm Seed --</option>
            <option value="Wheat">Wheat</option>
            <option value="Rice">Rice</option>
            <option value="Corn">Corn</option>
            <option value="Soybean">Soybean</option>
            <option value="Vegetables">Vegetables</option>
            <option value="Fruits">Fruits</option>
        </select>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit" class="submit-btn">Register</button>
    </form>

    <div class="back-link">
        <a href="login.php">⬅ Back to Login</a>
    </div>
</div>

</body>
</html>

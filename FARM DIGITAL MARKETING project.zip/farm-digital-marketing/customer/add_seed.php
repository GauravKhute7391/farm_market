<?php
session_start();
include('../config.php');

// Get logged-in customer
$customer_id = $_SESSION['user_id'] ?? 1;

// Fetch current seeds
$customer_query = mysqli_query($conn, "SELECT farm_available FROM customers WHERE customer_id = $customer_id");
$customer = mysqli_fetch_assoc($customer_query);

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seeds = $_POST['farm_available'] ?? '';
    $update_query = "UPDATE customers SET farm_available='$seeds' WHERE customer_id=$customer_id";

    if (mysqli_query($conn, $update_query)) {
        $message = "✅ Seeds updated successfully!";
        $customer['farm_available'] = $seeds; // update displayed value
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add/Update Seeds</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Montserrat', sans-serif;
    margin:0; padding:0;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)),
                url('../assets/farm7.jpg') no-repeat center center/cover;
    color:#fff;
    animation: fadeBody 1s ease forwards;
}
@keyframes fadeBody { from {opacity:0;} to {opacity:1;} }

.header {
    background: #FFD700;
    padding: 25px 20px;
    text-align: center;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    color: #333;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
}
.header h1 { margin:0; font-size:2rem; }

.container {
    max-width: 500px;
    margin: 40px auto;
    background: rgba(255,255,255,0.2);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    animation: fadeIn 1s ease forwards;
}
@keyframes fadeIn { from {opacity:0; transform:translateY(-20px);} to {opacity:1; transform:translateY(0);} }

.container h2 {
    text-align: center;
    color: #FFD700;
    margin-bottom: 25px;
    font-size: 1.8rem;
    text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
}

.container label {
    font-weight: 600;
    color: #fff;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}

.container select {
    width: 100%;
    padding: 12px;
    margin: 12px 0;
    border-radius: 8px;
    border:none;
    outline:none;
    font-size: 1rem;
    background: rgba(255,255,255,0.3);
    color:#fff;
    backdrop-filter: blur(5px);
    transition: 0.3s;
}
.container select:hover { background: rgba(255,255,255,0.4); }

.container button {
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    background:#FFD700;
    color:#333;
    font-weight:600;
    cursor:pointer;
    font-size:1rem;
    margin-top:10px;
    transition: 0.3s;
}
.container button:hover {
    background:#e6c200;
    transform: translateY(-2px) scale(1.03);
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}

.message {
    text-align:center;
    margin-bottom:15px;
    font-weight:bold;
    color:#0f0;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}

.back-link {
    text-align:center;
    margin-top:15px;
}
.back-link a {
    color:#FFD700;
    text-decoration:none;
    font-weight:600;
    transition:0.3s;
}
.back-link a:hover { text-decoration:underline; color:#e6c200; }
</style>
</head>
<body>

<div class="header">
    <h1>Add / Update Seeds</h1>
</div>

<div class="container">
    <?php if($message): ?>
        <div class="message"><?= $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <label for="farm_available">Select Your Available Seed:</label>
        <select name="farm_available" id="farm_available" required>
            <option value="">-- Select Seed --</option>
            <option value="Wheat" <?= ($customer['farm_available']=='Wheat')?'selected':''; ?>>Wheat</option>
            <option value="Rice" <?= ($customer['farm_available']=='Rice')?'selected':''; ?>>Rice</option>
            <option value="Corn" <?= ($customer['farm_available']=='Corn')?'selected':''; ?>>Corn</option>
            <option value="Soybean" <?= ($customer['farm_available']=='Soybean')?'selected':''; ?>>Soybean</option>
            <option value="Vegetables" <?= ($customer['farm_available']=='Vegetables')?'selected':''; ?>>Vegetables</option>
            <option value="Fruits" <?= ($customer['farm_available']=='Fruits')?'selected':''; ?>>Fruits</option>
        </select>

        <button type="submit">Save Seed</button>
    </form>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>

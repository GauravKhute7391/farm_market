<?php
session_start();
include('../config.php');

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Fetch all employees
$employees_query = "SELECT * FROM employees ORDER BY created_at DESC";
$employees_result = mysqli_query($conn, $employees_query);
$employees = mysqli_fetch_all($employees_result, MYSQLI_ASSOC);

// Handle delete request
if(isset($_GET['delete_id'])){
    $delete_id = intval($_GET['delete_id']);

    // Fetch employee info before deletion for logging
    $emp_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM employees WHERE employee_id='$delete_id'"));

    if($emp_info){
        $employee_name = mysqli_real_escape_string($conn, $emp_info['full_name']);
        $farm_seed_type = mysqli_real_escape_string($conn, $emp_info['farm_type']);
        $activity_date = date('Y-m-d H:i:s');

        // Insert into employee_activity
        mysqli_query($conn, "INSERT INTO employee_activity 
            (employee_id, employee_name, farm_seed_type, profit, loss, activity_date, action)
            VALUES ('$delete_id', '$employee_name', '$farm_seed_type', 0, 0, '$activity_date', 'Deleted')");
    }

    // Delete employee
    mysqli_query($conn, "DELETE FROM employees WHERE employee_id='$delete_id'");
    header("Location: manage_employees.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Employees</title>
<style>
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    color:#fff;
    padding:20px;
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url("../assets/tractor123.jpg") no-repeat center center fixed;
    background-size: cover;
}
.container {
    width: 95%;
    max-width: 1300px;
    margin:0 auto;
    opacity: 0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}
@keyframes slideIn {
    from { opacity:0; transform: translateY(50px); }
    to { opacity:1; transform: translateY(0); }
}
h2 {
    text-align:center;
    margin-bottom:30px;
    color:#FFD700;
    font-size:2rem;
    text-shadow:1px 1px 4px rgba(0,0,0,0.7);
}
.add-btn {
    display:inline-block;
    margin-bottom:15px;
    padding:10px 20px;
    background:#28a745;
    color:#fff;
    border-radius:8px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.add-btn:hover { background:#218838; }
.table-container {
    overflow-x: auto;
}
table {
    width:100%;
    border-collapse: collapse;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius:15px;
    display: block;
    animation: fadeIn 1s ease forwards;
}
th, td {
    padding:12px 15px;
    text-align:left;
    border-bottom:1px solid rgba(255,255,255,0.2);
}
th {
    background: rgba(255,255,255,0.2);
    font-weight:bold;
}
tr:hover { background: rgba(255,255,255,0.2); }
.action-btn {
    padding:6px 12px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-weight:bold;
    color:#fff;
    transition:0.3s;
}
.edit-btn { background:#FFD700; color:#000; }
.edit-btn:hover { background:#e6c200; }
.delete-btn { background:#dc3545; }
.delete-btn:hover { background:#b21f2d; }
.back-btn {
    display:inline-block;
    margin-top:20px;
    padding:10px 20px;
    background:#FF6F61;
    border-radius:8px;
    text-decoration:none;
    color:#fff;
    font-weight:bold;
    transition:0.3s;
}
.back-btn:hover { background:#e65c50; }
@keyframes fadeIn { from {opacity:0; transform: translateY(-20px);} to {opacity:1; transform:translateY(0);} }
</style>
</head>
<body>

<div class="container">
    <h2>Manage Employees</h2>
    <a href="add_employee.php" class="add-btn">+ Add New Employee</a>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Farm Type</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($employees): ?>
                    <?php foreach($employees as $emp): ?>
                        <tr>
                            <td><?= $emp['employee_id']; ?></td>
                            <td><?= htmlspecialchars($emp['full_name']); ?></td>
                            <td><?= htmlspecialchars($emp['username']); ?></td>
                            <td><?= htmlspecialchars($emp['email']); ?></td>
                            <td><?= htmlspecialchars($emp['phone']); ?></td>
                            <td><?= htmlspecialchars($emp['farm_type']); ?></td>
                            <td><?= date('d-m-Y H:i', strtotime($emp['created_at'])); ?></td>
                            <td>
                                <a href="edit_employee.php?employee_id=<?= $emp['employee_id']; ?>" class="action-btn edit-btn">Edit</a>
                                <a href="manage_employees.php?delete_id=<?= $emp['employee_id']; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure to delete this employee?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="8" style="text-align:center;">No employees found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <a href="dashboard.php" class="back-btn">⬅ Back to Dashboard</a>
</div>

</body>
</html>

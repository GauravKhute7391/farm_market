<?php
session_start();
include('../config.php');

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Get activity_id from URL
if (!isset($_GET['activity_id'])) {
    header("Location: activity_history.php");
    exit;
}

$activity_id = intval($_GET['activity_id']);
$message = "";

// Fetch current activity
$query = "SELECT * FROM employee_activity WHERE activity_id='$activity_id' LIMIT 1";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 0) {
    header("Location: activity_history.php");
    exit;
}
$activity = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = mysqli_real_escape_string($conn, $_POST['employee_id']);
    $employee_name = mysqli_real_escape_string($conn, $_POST['employee_name']);
    $farm_seed_type = mysqli_real_escape_string($conn, $_POST['farm_seed_type']);
    $profit = floatval($_POST['profit']);
    $loss = floatval($_POST['loss']);
    $activity_date = $_POST['activity_date'];

    $update_query = "
    UPDATE employee_activity 
    SET employee_id='$employee_id', employee_name='$employee_name', farm_seed_type='$farm_seed_type',
        profit='$profit', loss='$loss', activity_date='$activity_date'
    WHERE activity_id='$activity_id'
    ";

    if (mysqli_query($conn, $update_query)) {
        $message = "✅ Activity updated successfully!";
        // Refresh data
        $activity = mysqli_fetch_assoc(mysqli_query($conn, $query));
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Activity</title>
<style>
body {
    font-family:'Segoe UI',sans-serif;
    margin:0;
    padding:0;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url("../assets/tractor123.jpg") no-repeat center center fixed;
    background-size: cover;
    color:#fff;
}

.container {
    max-width: 700px;
    margin: 40px auto;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    padding: 30px;
    opacity:0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}

@keyframes slideIn {
    from { opacity:0; transform: translateY(50px); }
    to { opacity:1; transform: translateY(0); }
}

h2 {
    text-align:center;
    margin-bottom: 25px;
    font-size:2rem;
    color:#FFD700;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
}

form {
    display: grid;
    gap:15px;
}

form input, form select {
    padding:10px;
    border:none;
    border-radius:8px;
    outline:none;
    width:100%;
}

form button {
    background: #FF6F61;
    color:white;
    border:none;
    padding:12px;
    border-radius:8px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

form button:hover {
    background:#e65c50;
}

.message {
    text-align:center;
    margin-bottom:20px;
    font-weight:bold;
}

.back-btn {
    display:inline-block;
    margin-top:20px;
    padding:10px 20px;
    background:#FF6F61;
    border-radius:8px;
    text-decoration:none;
    color:#fff;
    font-weight:bold;
    transition:0.3s;
}
.back-btn:hover { background:#e65c50; box-shadow:0 5px 15px rgba(0,0,0,0.3); }
</style>
</head>
<body>

<div class="container">
    <h2>✏️ Edit Employee Activity</h2>

    <?php if($message): ?>
        <div class="message"><?= $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="number" name="employee_id" placeholder="Employee ID" value="<?= $activity['employee_id']; ?>" required>
        <input type="text" name="employee_name" placeholder="Employee Name" value="<?= htmlspecialchars($activity['employee_name']); ?>" required>

        <select name="farm_seed_type" required>
            <option value="">Select Farm Seed Type</option>
            <option value="Wheat" <?= $activity['farm_seed_type']=='Wheat' ? 'selected' : ''; ?>>Wheat</option>
            <option value="Rice" <?= $activity['farm_seed_type']=='Rice' ? 'selected' : ''; ?>>Rice</option>
            <option value="Sugarcane" <?= $activity['farm_seed_type']=='Sugarcane' ? 'selected' : ''; ?>>Sugarcane</option>
            <option value="Cotton" <?= $activity['farm_seed_type']=='Cotton' ? 'selected' : ''; ?>>Cotton</option>
        </select>

        <input type="number" step="0.01" name="profit" placeholder="Profit" value="<?= $activity['profit']; ?>" required>
        <input type="number" step="0.01" name="loss" placeholder="Loss" value="<?= $activity['loss']; ?>" required>
        <input type="date" name="activity_date" value="<?= $activity['activity_date']; ?>" required>

        <button type="submit">Update Activity</button>
    </form>

    <a href="activity_history.php" class="back-btn">⬅ Back to Activity History</a>
</div>

</body>
</html>

<?php
session_start();
include('../config.php');

// Only admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$message = "";

// Add new schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $activity_name = mysqli_real_escape_string($conn, $_POST['activity_name']);
    $farm_seed_type = mysqli_real_escape_string($conn, $_POST['farm_seed_type']);
    $schedule_date = $_POST['schedule_date'];
    $assigned_employee = mysqli_real_escape_string($conn, $_POST['assigned_employee']);
    $remarks = mysqli_real_escape_string($conn, $_POST['remarks']);

    $query = "INSERT INTO farm_schedule (activity_name, farm_seed_type, schedule_date, assigned_employee, remarks)
              VALUES ('$activity_name', '$farm_seed_type', '$schedule_date', '$assigned_employee', '$remarks')";
    if (mysqli_query($conn, $query)) {
        $message = "✅ Schedule added successfully!";
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}

// Delete schedule
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM farm_schedule WHERE schedule_id=$id");
    header("Location: farm_schedule.php");
    exit;
}

// Fetch schedules
$schedules = mysqli_query($conn, "SELECT * FROM farm_schedule ORDER BY schedule_date ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin | Farm Schedule</title>
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    margin: 0;
    padding: 0;
    min-height: 100vh;
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url('../assets/tractor123.jpg') no-repeat center center fixed;
    background-size: cover;
    color: #fff;
}
.container {
    width: 95%;              /* Wider container */
    max-width: 1400px;       /* Larger max width */
    margin: 30px auto;
    background: rgba(255,255,255,0.1);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    backdrop-filter: blur(12px);
    opacity:0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}
@keyframes slideIn {
    from { opacity:0; transform:translateY(50px); }
    to { opacity:1; transform:translateY(0); }
}
h2 {
    text-align:center;
    margin-bottom: 20px;
    font-size: 2rem;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.6);
}
form {
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 30px;
}
form input, form select, form textarea {
    padding: 10px;
    border:none;
    border-radius: 8px;
    width:100%;
    outline:none;
}
form button {
    grid-column: span 2;
    background: #FF6F61;
    color:white;
    border:none;
    padding:12px;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
    transition:0.3s;
}
form button:hover {
    background:#e65c50;
}

.message {
    text-align:center;
    margin-bottom:20px;
    font-weight:bold;
}

.table-container {
    overflow-x:auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 900px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(8px);
    border-radius:12px;
}
th, td {
    padding:10px;
    border-bottom:1px solid rgba(255,255,255,0.2);
    text-align:center;
}
th {
    background: rgba(255,255,255,0.2);
}
tr:hover {
    background: rgba(255,255,255,0.2);
    transform: scale(1.01);
    transition: 0.2s;
}
.action-btn {
    padding:6px 12px;
    border:none;
    border-radius:6px;
    font-weight:bold;
    color:#fff;
    text-decoration:none;
    margin:0 3px;
    transition:0.3s;
}
.edit-btn { background:#FFD700; color:#000; }
.edit-btn:hover { background:#e6c200; }
.delete-btn { background:#dc3545; }
.delete-btn:hover { background:#b21f2d; }

.back {
    text-align:center;
    margin-top:20px;
}
.back a {
    background:#FF6F61;
    color:white;
    text-decoration:none;
    padding:10px 20px;
    border-radius:8px;
    font-weight:bold;
    transition:0.3s;
}
.back a:hover {
    background:#e65c50;
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}
</style>
</head>
<body>

<div class="container">
    <h2>🌾 Farm Activity Schedule</h2>

    <?php if($message): ?>
        <div class="message"><?= $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="activity_name" placeholder="Enter Activity Name" required>
        <select name="farm_seed_type" required>
            <option value="">Select Farm Seed Type</option>
            <option value="Wheat">Wheat</option>
            <option value="Rice">Rice</option>
            <option value="Sugarcane">Sugarcane</option>
            <option value="Cotton">Cotton</option>
        </select>
        <input type="date" name="schedule_date" value="<?= date('Y-m-d'); ?>" required>
        <input type="text" name="assigned_employee" placeholder="Assign Employee Name" required>
        <textarea name="remarks" rows="3" placeholder="Remarks or Instructions"></textarea>
        <button type="submit">Add Schedule</button>
    </form>

    <h3 style="margin-top:30px;">📋 Scheduled Activities</h3>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Activity</th>
                    <th>Farm Seed</th>
                    <th>Date</th>
                    <th>Assigned Employee</th>
                    <th>Remarks</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($schedules) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($schedules)): ?>
                    <tr>
                        <td><?= $row['schedule_id']; ?></td>
                        <td><?= htmlspecialchars($row['activity_name']); ?></td>
                        <td><?= htmlspecialchars($row['farm_seed_type']); ?></td>
                        <td><?= $row['schedule_date']; ?></td>
                        <td><?= htmlspecialchars($row['assigned_employee']); ?></td>
                        <td><?= htmlspecialchars($row['remarks']); ?></td>
                        <td>
                            <a href="edit_schedule.php?id=<?= $row['schedule_id']; ?>" class="action-btn edit-btn">Edit</a>
                            <a href="?delete=<?= $row['schedule_id']; ?>" class="action-btn delete-btn" onclick="return confirm('Delete this record?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7">No scheduled activities yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="back">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>

<?php
session_start();
include('../config.php');

// Only admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Get schedule ID
if (!isset($_GET['id'])) {
    header("Location: farm_schedule.php");
    exit;
}

$schedule_id = intval($_GET['id']);

// Fetch existing schedule
$result = mysqli_query($conn, "SELECT * FROM farm_schedule WHERE schedule_id = $schedule_id");
if (mysqli_num_rows($result) == 0) {
    header("Location: farm_schedule.php");
    exit;
}
$schedule = mysqli_fetch_assoc($result);

$message = "";

// Update schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $activity_name = mysqli_real_escape_string($conn, $_POST['activity_name']);
    $farm_seed_type = mysqli_real_escape_string($conn, $_POST['farm_seed_type']);
    $schedule_date = $_POST['schedule_date'];
    $assigned_employee = mysqli_real_escape_string($conn, $_POST['assigned_employee']);
    $remarks = mysqli_real_escape_string($conn, $_POST['remarks']);

    $update = "UPDATE farm_schedule 
               SET activity_name='$activity_name', farm_seed_type='$farm_seed_type', 
                   schedule_date='$schedule_date', assigned_employee='$assigned_employee', 
                   remarks='$remarks'
               WHERE schedule_id=$schedule_id";

    if (mysqli_query($conn, $update)) {
        $message = "✅ Schedule updated successfully!";
        // Refresh to show updated data
        $schedule = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM farm_schedule WHERE schedule_id = $schedule_id"));
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Schedule | Admin</title>
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    margin:0;
    padding:0;
    min-height:100vh;
    background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)),
                url('../assets/tractor123.jpg') no-repeat center center fixed;
    background-size: cover;
    color:#fff;
}
.container {
    width:95%;
    max-width: 900px;
    margin: 40px auto;
    background: rgba(255,255,255,0.1);
    padding: 25px 30px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    backdrop-filter: blur(12px);
    opacity:0;
    transform: translateY(50px);
    animation: slideIn 1s forwards;
}
@keyframes slideIn { from { opacity:0; transform:translateY(50px); } to { opacity:1; transform:translateY(0); } }
h2 { text-align:center; margin-bottom:20px; font-size:2rem; text-shadow:1px 1px 4px rgba(0,0,0,0.6); }
form { display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom: 30px; }
form input, form select, form textarea { padding:10px; border:none; border-radius:8px; width:100%; outline:none; }
form button { grid-column: span 2; background: #FFD700; color:black; border:none; padding:12px; border-radius:8px; cursor:pointer; font-weight:bold; transition:0.3s; }
form button:hover { background:#e6c200; }
.message { text-align:center; margin-bottom:20px; font-weight:bold; }
.back { text-align:center; margin-top:20px; }
.back a { background:#FF6F61; color:white; text-decoration:none; padding:10px 20px; border-radius:8px; font-weight:bold; transition:0.3s; }
.back a:hover { background:#e65c50; box-shadow:0 5px 15px rgba(0,0,0,0.3); }
</style>
</head>
<body>

<div class="container">
    <h2>✏️ Edit Farm Schedule</h2>

    <?php if($message): ?>
        <div class="message"><?= $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="activity_name" placeholder="Activity Name" value="<?= htmlspecialchars($schedule['activity_name']); ?>" required>
        <select name="farm_seed_type" required>
            <option value="">Select Farm Seed Type</option>
            <option value="Wheat" <?= $schedule['farm_seed_type']=='Wheat'?'selected':''; ?>>Wheat</option>
            <option value="Rice" <?= $schedule['farm_seed_type']=='Rice'?'selected':''; ?>>Rice</option>
            <option value="Sugarcane" <?= $schedule['farm_seed_type']=='Sugarcane'?'selected':''; ?>>Sugarcane</option>
            <option value="Cotton" <?= $schedule['farm_seed_type']=='Cotton'?'selected':''; ?>>Cotton</option>
            
        </select>
        <input type="date" name="schedule_date" value="<?= $schedule['schedule_date']; ?>" required>
        <input type="text" name="assigned_employee" placeholder="Assign Employee Name" value="<?= htmlspecialchars($schedule['assigned_employee']); ?>" required>
        <textarea name="remarks" rows="3" placeholder="Remarks"><?= htmlspecialchars($schedule['remarks']); ?></textarea>
        <button type="submit">Update Schedule</button>
    </form>

    <div class="back">
        <a href="farm_schedule.php">⬅ Back to Schedule</a>
    </div>
</div>

</body>
</html>

<?php
session_start();
include('../config.php');

// Check admin login
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = trim($_POST['full_name']);
    $username  = trim($_POST['username']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $farm_type = trim($_POST['farm_type']);
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if username exists
    $check_query = mysqli_query($conn, "SELECT * FROM employees WHERE username='$username'");
    if(mysqli_num_rows($check_query) > 0){
        $message = "Username already exists!";
    } else {
        $insert = mysqli_query($conn, "INSERT INTO employees (full_name, username, email, phone, farm_type, password) 
                                       VALUES ('$full_name','$username','$email','$phone','$farm_type','$password')");
        if($insert){
            header("Location: manage_employees.php");
            exit;
        } else {
            $message = "Error adding employee. Try again!";
        }
    }
}

// Example farm types
$farm_types = ['Vegetables','Fruits','Grains','Dairy','Poultry','Flowers'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Employee</title>
<style>
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background: linear-gradient(135deg,#1f1c2c,#928dab);
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:flex-start;
    min-height:100vh;
    padding:50px 20px;
}

.form-container {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(15px);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    width: 400px;
    animation: fadeIn 1s ease forwards;
}

h2 {
    text-align:center;
    margin-bottom:25px;
    color:#FFD700;
    font-size:2rem;
    text-shadow:1px 1px 4px rgba(0,0,0,0.5);
}

input, select {
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:10px;
    outline:none;
    font-size:1rem;
}

button {
    width:100%;
    padding:12px;
    margin-top:10px;
    background:#FF6F61;
    border:none;
    border-radius:10px;
    font-size:1.1rem;
    font-weight:bold;
    color:#fff;
    cursor:pointer;
    transition:0.3s;
}

button:hover {
    background:#e65c50;
    transform:translateY(-2px);
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

.error {
    background: rgba(255,0,0,0.4);
    padding:8px;
    border-radius:6px;
    margin-bottom:10px;
    text-align:center;
}

.back-btn {
    display:inline-block;
    margin-top:20px;
    padding:8px 15px;
    background:#FFD700;
    border-radius:8px;
    text-decoration:none;
    color:#000;
    font-weight:bold;
    transition:0.3s;
}
.back-btn:hover { background:#e6c200; }

@keyframes fadeIn { from {opacity:0; transform: translateY(-20px);} to {opacity:1; transform:translateY(0);} }
</style>
</head>
<body>

<div class="form-container">
    <h2>Add New Employee</h2>

    <?php if($message): ?>
        <div class="error"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <select name="farm_type" required>
            <option value="">Select Farm Type</option>
            <?php foreach($farm_types as $type): ?>
                <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
            <?php endforeach; ?>
        </select>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Add Employee</button>
    </form>

    <a href="manage_employees.php" class="back-btn">⬅ Back to Manage Employees</a>
</div>

</body>
</html>

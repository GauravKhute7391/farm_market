<?php
session_start();
include('../config.php');

// Admin authentication
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== "admin") {
    header("Location: login.php");
    exit;
}

// Get auction ID from URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: auctions.php");
    exit;
}

$auction_id = $_GET['id'];

// Fetch auction details
$result = mysqli_query($conn, "SELECT * FROM seed_auctions WHERE auction_id = $auction_id");
$auction = mysqli_fetch_assoc($result);

if (!$auction) {
    echo "<h2 style='color:red;text-align:center;'>Auction record not found!</h2>";
    exit;
}

// Fetch all employees
$employees = mysqli_query($conn, "SELECT employee_id, full_name FROM employees");

// Update auction
if (isset($_POST['update_auction'])) {
    $seed_name = trim($_POST['seed_name']);
    $price = $_POST['price'];
    $auction_date = $_POST['auction_date'];
    $employee_id = $_POST['employee_id'];

    $update = "UPDATE seed_auctions 
               SET seed_name='$seed_name', price='$price', auction_date='$auction_date', employee_id='$employee_id' 
               WHERE auction_id=$auction_id";
    mysqli_query($conn, $update);

    header("Location: auctions.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Auction | Admin Panel</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #43cea2, #185a9d);
      color: #fff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.8s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .container {
      width: 400px;
      background: rgba(255,255,255,0.1);
      backdrop-filter: blur(10px);
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.3);
      animation: slideUp 0.8s ease;
    }

    @keyframes slideUp {
      from { transform: translateY(20px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    input, select, button {
      padding: 10px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      outline: none;
    }

    input, select {
      background: rgba(255,255,255,0.85);
      color: #333;
    }

    button {
      background: #FF6F61;
      color: white;
      cursor: pointer;
      transition: 0.3s;
      font-weight: bold;
    }

    button:hover {
      background: #e65b50;
      transform: scale(1.05);
    }

    .back {
      text-align: center;
      margin-top: 20px;
    }

    .back a {
      color: #fff;
      text-decoration: none;
      background: rgba(0,0,0,0.4);
      padding: 8px 15px;
      border-radius: 8px;
      transition: 0.3s;
    }

    .back a:hover {
      background: rgba(0,0,0,0.6);
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>✏️ Edit Seed Auction</h2>
    <form method="POST">
      <input type="text" name="seed_name" value="<?= htmlspecialchars($auction['seed_name']) ?>" placeholder="Seed Name" required>
      <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($auction['price']) ?>" placeholder="Price (₹)" required>
      <input type="date" name="auction_date" value="<?= htmlspecialchars($auction['auction_date']) ?>" required>

      <select name="employee_id" required>
        <option value="">Select Employee</option>
        <?php while($emp = mysqli_fetch_assoc($employees)): ?>
          <option value="<?= $emp['employee_id'] ?>" 
            <?= ($auction['employee_id'] == $emp['employee_id']) ? 'selected' : '' ?>>
            <?= $emp['full_name'] ?>
          </option>
        <?php endwhile; ?>
      </select>

      <button type="submit" name="update_auction">💾 Update Auction</button>
    </form>

    <div class="back">
      <a href="auctions.php">⬅ Back to Auctions</a>
    </div>
  </div>

</body>
</html>

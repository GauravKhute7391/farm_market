<?php
include('../config.php');

// Fetch all scheduled farm visits
$query = "SELECT * FROM farm_schedule ORDER BY schedule_date ASC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Farm Visit Dates</title>
<style>
/* Body & Background */
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    min-height:100vh;
    background: linear-gradient(135deg,#76b852,#8DC26F,#FF6F61,#00BFFF);
    background-size:400% 400%;
    animation: gradientBG 15s ease infinite;
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:flex-start;
    padding:50px 20px;
    background-image: url('../assets/farm2.jpg'); /* add your image path */
    background-size: cover;
    background-attachment: fixed;
    background-position: center;
    background-blend-mode: overlay; /* blend gradient with image */
}

@keyframes gradientBG {
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

/* Container */
.container {
    width: 95%;
    max-width:1200px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(15px);
    padding:30px;
    border-radius:20px;
    box-shadow:0 10px 30px rgba(0,0,0,0.5);
    animation: fadeContainer 1s ease forwards;
}

@keyframes fadeContainer {
    from {opacity:0; transform:translateY(20px);}
    to {opacity:1; transform:translateY(0);}
}

/* Heading */
h2 {
    text-align:center;
    margin-bottom:30px;
    font-size:2rem;
    color:#FFD700;
    text-shadow: 1px 1px 4px rgba(0,0,0,0.5);
}

/* Table Styling */
table {
    width:100%;
    border-collapse: collapse;
    overflow:hidden;
    border-radius:10px;
}

th, td {
    padding:12px;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,0.3);
    color:#fff;
}

th {
    background: rgba(0,0,0,0.3);
    font-weight:bold;
}

tr:hover {
    background: rgba(255,255,255,0.2);
    transform:scale(1.01);
    transition:0.3s;
}

/* Back Link Button */
.back-link {
    text-align:center;
    margin-top:25px;
}
.back-link a {
    display:inline-block;
    background:#FFD700;
    color:#000;
    padding:12px 25px;
    border-radius:10px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.back-link a:hover {
    background:#e5c100;
}

/* Responsive */
@media(max-width:768px){
    table, thead, tbody, th, td, tr { display:block; }
    th { position:absolute; top:-9999px; left:-9999px; }
    td { border:none; position:relative; padding-left:50%; margin-bottom:10px; }
    td:before { 
        position:absolute; 
        top:12px; 
        left:12px; 
        width:45%; 
        padding-right:10px; 
        white-space: nowrap; 
        font-weight:bold; 
        content: attr(data-label);
        color:#FFD700;
    }
}
</style>
</head>
<body>

<div class="container">
    <h2>📅 Scheduled Farm Visits</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Activity</th>
                <th>Farm Seed</th>
                <th>Date</th>
                <th>Assigned Employee</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td data-label="ID"><?= $row['schedule_id']; ?></td>
                        <td data-label="Activity"><?= htmlspecialchars($row['activity_name']); ?></td>
                        <td data-label="Farm Seed"><?= htmlspecialchars($row['farm_seed_type']); ?></td>
                        <td data-label="Date"><?= htmlspecialchars($row['schedule_date']); ?></td>
                        <td data-label="Assigned Employee"><?= htmlspecialchars($row['assigned_employee']); ?></td>
                        <td data-label="Remarks"><?= htmlspecialchars($row['remarks']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center;">No scheduled activities found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="back-link">
        <a href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>

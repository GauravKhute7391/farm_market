<?php
session_start();
include('../config.php');

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee') {
    header("Location: login.php");
    exit;
}

$employee_id = $_SESSION['employee_id'];

if (isset($_GET['customer_id'])) {
    $customer_id = intval($_GET['customer_id']);

    // Check if request already exists today
    $check = mysqli_query($conn, "SELECT * FROM employee_requests WHERE employee_id='$employee_id' AND customer_id='$customer_id' AND DATE(request_date)=CURDATE()");
    if (mysqli_num_rows($check) === 0) {
        // Insert request
        mysqli_query($conn, "INSERT INTO employee_requests (employee_id, customer_id) VALUES ('$employee_id', '$customer_id')");
        $message = "✅ Request sent successfully!";
    } else {
        $message = "⚠️ You already sent a request to this customer today.";
    }
} else {
    $message = "❌ Invalid customer!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Request Customer</title>
<style>
body { font-family:'Segoe UI',sans-serif; background:#222; color:#fff; display:flex; justify-content:center; align-items:center; height:100vh; }
.card { background: rgba(255,255,255,0.1); padding:30px; border-radius:20px; text-align:center; box-shadow:0 10px 25px rgba(0,0,0,0.5); }
a { color:#FFD700; text-decoration:none; font-weight:bold; }
a:hover { text-decoration:underline; }
</style>
</head>
<body>
<div class="card">
    <p><?php echo $message; ?></p>
    <a href="dashboard.php">⬅ Back to Dashboard</a>
</div>
</body>
</html>

<?php
session_start();
include('../config.php');

// Check if user is logged in
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'employee' || !isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo "Unauthorized: session not found";
    exit;
}

$employee_id = $_SESSION['user_id'];
$employee_name = $_SESSION['user_name'] ?? 'Employee';

if(isset($_POST['farm_seed_type'], $_POST['profit'], $_POST['loss'], $_POST['activity_date'])){
    $farm_seed_type = mysqli_real_escape_string($conn, $_POST['farm_seed_type']);
    $profit = floatval($_POST['profit']);
    $loss = floatval($_POST['loss']);
    $activity_date = $_POST['activity_date'];

    $insert_query = "INSERT INTO employee_activity (employee_id, employee_name, farm_seed_type, profit, loss, activity_date)
                     VALUES ($employee_id, '$employee_name', '$farm_seed_type', $profit, $loss, '$activity_date')";

    if(mysqli_query($conn, $insert_query)){
        $result_query = "SELECT farm_seed_type, profit, loss, activity_date
                         FROM employee_activity
                         WHERE employee_id = $employee_id
                         ORDER BY activity_date DESC";
        $result = mysqli_query($conn, $result_query);
        $activities = mysqli_fetch_all($result, MYSQLI_ASSOC);

        foreach($activities as $index => $act){
            echo "<tr>
                    <td>".($index+1)."</td>
                    <td>".htmlspecialchars($act['farm_seed_type'])."</td>
                    <td class='profit'>".number_format($act['profit'],2)."</td>
                    <td class='loss'>".number_format($act['loss'],2)."</td>
                    <td>".date('d-m-Y', strtotime($act['activity_date']))."</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='5' style='text-align:center;'>Error: ".mysqli_error($conn)."</td></tr>";
    }
}
?>
